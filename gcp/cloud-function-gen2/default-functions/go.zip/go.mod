module github.com/NandosUK/nandos-id-infrastructure/infrastructure/gcp/utils/default-go-function/src

go 1.16
