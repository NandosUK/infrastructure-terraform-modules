package function

import (
	"net/http"
)

func Entrypoint(w http.ResponseWriter, r *http.Request) {
	panic("not implemented")
}
